pip install tensorflow
pip install tf-agents
pip install gym
pip install matplotlib