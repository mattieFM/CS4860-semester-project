# CS4860-semester-project
Semester project with cs 4860.


# description
A RL model trained to see if it can solve triangles  

Run py ./ml_model to get results for the current implementation of our RL agent solving triangles.


# files
This section included info on each file in this project  

## triangle_gen.py
This is a file that generates valid triangles.
also classifies the triangles as one of: AAA, AAS, ASA, SAS, SSA, SSS, or UNSOLVABLE, that is angle angle angle, angle angle side, etc... the types that are usually tought in basic geometry
